<?php
require_once 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') header("Location: index.php");
$students = $conn->query("SELECT * FROM users WHERE role='student'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-danger">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">School App - Admin</a>
        <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>
<div class="container mt-4">
    <h2>Dashboard Admin</h2>
    <p>Kelola data siswa:</p>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead class="table-light">
            <tr>
                <th>Foto</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Deskripsi</th>
            </tr>
            </thead>
            <tbody>
            <?php while($s = $students->fetch_assoc()): ?>
                <tr>
                    <td><img src="<?= $s['photo'] ?>" width="50" height="50" class="rounded-circle"></td>
                    <td><?= htmlspecialchars($s['name']) ?></td>
                    <td><?= htmlspecialchars($s['email']) ?></td>
                    <td><?= nl2br(htmlspecialchars($s['description'] ?: '-')) ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>