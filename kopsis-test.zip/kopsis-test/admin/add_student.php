<?php
require_once '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') header("Location: ../index.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis     = strtoupper(trim($_POST['nis']));
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $pass    = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $kelas   = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $role    = 'student'; // OTOMATIS
    $photo   = 'assets/img/default.png'; // Default

    // Validasi NIS & Email unik
    $stmt = $conn->prepare("SELECT id FROM users WHERE nis=? OR email=?");
    $stmt->bind_param("ss", $nis, $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows) {
        header("Location: dashboard.php?error=exists");
        exit;
    }

    // Upload foto (opsional)
    if (!empty($_FILES['photo']['name'])) {
        $file = $_FILES['photo'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];
        if (in_array($ext, $allowed)) {
            $path = "assets/uploads/" . uniqid() . ".$ext";
            if (move_uploaded_file($file['tmp_name'], $path)) {
                $photo = $path;
            }
        }
    }

    // Insert ke DB
    $stmt = $conn->prepare("INSERT INTO users (nis,name,email,password,role,kelas,jurusan,photo) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssss", $nis, $name, $email, $pass, $role, $kelas, $jurusan, $photo);
    $stmt->execute();

    header("Location: dashboard.php?added=1");
    exit;
}
?>