<?php
require_once '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') header("Location: ../index.php");

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id=? AND role='student'");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?deleted=1");
    exit;
}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="data_siswa_' . date('Y-m-d') . '.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['NIS', 'Nama', 'Email', 'Kelas', 'Jurusan']);

    $res = $conn->query("SELECT nis,name,email,kelas,jurusan FROM users WHERE role='student'");
    while ($row = $res->fetch_assoc()) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// Data siswa
$siswa = $conn->query("SELECT * FROM users WHERE role='student' ORDER BY updated_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin - Koperasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-dark text-white">

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark bg-black">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="bi bi-speedometer2 me-2"></i>Admin Panel</a>
    <div class="ms-auto">
      <a href="../profile.php" class="btn btn-outline-light btn-sm me-2">Profile</a>
      <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="py-5 text-center bg-gradient-dark">
  <h1 class="display-5 fw-bold">Dashboard Admin</h1>
  <p class="lead">Kelola data siswa & backup data koperasi.</p>
</section>

<?php if (isset($_GET['added'])): ?>
  <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
    <i class="bi bi-check-circle me-2"></i>Siswa berhasil ditambahkan!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php elseif (isset($_GET['error']) && $_GET['error'] === 'exists'): ?>
  <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
    <i class="bi bi-exclamation-circle me-2"></i>NIS atau Email sudah terdaftar!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<!-- Tabel Siswa -->
<section class="py-4">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4><i class="bi bi-people me-2"></i>Data Siswa</h4>
      <div>
        <a href="?export=csv" class="btn btn-success btn-sm me-2"><i class="bi bi-download me-1"></i>Backup CSV</a>
        <!-- Tombol Tambah Siswa -->
        <div class="text-center mt-4">
        <button class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#addStudentModal">
            <i class="bi bi-plus-circle me-2"></i>Tambah Siswa Baru
        </button>
        </div>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-dark table-hover align-middle">
        <thead>
          <tr>
            <th>Foto</th>
            <th>NIS</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Jurusan</th>
            <th>Email</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($s = $siswa->fetch_assoc()): ?>
            <tr>
              <td><img src="../<?= $s['photo'] ?>" width="40" height="40" class="rounded-circle"></td>
              <td><?= $s['nis'] ?></td>
              <td><?= $s['name'] ?></td>
              <td><?= $s['kelas'] ?></td>
              <td><?= $s['jurusan'] ?></td>
              <td><?= $s['email'] ?></td>
              <td>
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $s['id'] ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <a href="?delete=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus?')">
                  <i class="bi bi-trash"></i>
                </a>
              </td>
            </tr>

            <!-- Modal Tambah Siswa -->
            <div class="modal fade text-dark" id="addStudentModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                <form method="POST" action="add_student.php" enctype="multipart/form-data">
                    <div class="modal-header">
                    <h5 class="modal-title">Tambah Siswa Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                    <div class="mb-3">
                        <label>NIS</label>
                        <input type="text" name="nis" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required minlength="6">
                    </div>
                    <div class="mb-3">
                        <label>Kelas</label>
                        <select name="kelas" class="form-select" required>
                        <?php foreach(['X-1','X-2','X-3','XI-1','XI-2','XI-3','XII-1','XII-2','XII-3'] as $k): ?>
                            <option value="<?= $k ?>"><?= $k ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Jurusan</label>
                        <select name="jurusan" class="form-select" required>
                        <?php foreach(['IPA','IPS','Bahasa','Agama','IPS'] as $j): ?>
                            <option value="<?= $j ?>"><?= $j ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Foto</label>
                        <input type="file" class="form-control" name="photo" accept="image/*">
                    </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
                </div>
            </div>
            </div>
            <!-- Modal Edit Siswa + Foto -->
            <div class="modal fade text-dark" id="edit<?= $s['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="POST" action="edit_siswa.php" enctype="multipart/form-data">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Siswa</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                      <input type="hidden" name="id" value="<?= $s['id'] ?>">
                      <div class="mb-3">
                        <label>NIS</label>
                        <input type="text" name="nis" class="form-control" value="<?= htmlspecialchars($s['nis']) ?>" required>
                      </div>
                      <div class="mb-3">
                        <label>Nama</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($s['name']) ?>" required>
                      </div>
                      <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($s['email']) ?>" required>
                      </div>
                      <div class="mb-3">
                        <label>Kelas</label>
                        <select name="kelas" class="form-select" required>
                          <?php foreach(['X-1','X-2','X-3','XI-1','XI-2','XI-3','XII-1','XII-2','XII-3'] as $k): ?>
                            <option value="<?= $k ?>" <?= $k==$s['kelas']?'selected':'' ?>><?= $k ?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                      <div class="mb-3">
                        <label>Jurusan</label>
                        <select name="jurusan" class="form-select" required>
                          <?php foreach(['IPA','IPS','Bahasa','Agama','IPS'] as $j): ?>
                            <option value="<?= $j ?>" <?= $j==$s['jurusan']?'selected':'' ?>><?= $j ?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                      <div class="mb-3">
                        <label>Foto (opsional)</label>
                        <input type="file" class="form-control" name="photo" accept="image/*">
                        <small class="text-muted">Kosongkan jika tidak ingin mengubah foto</small>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="bg-black text-white py-3 mt-5">
  <div class="container text-center">
    <small>&copy; <?= date('Y') ?> Koperasi Siswa – All rights reserved.</small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>