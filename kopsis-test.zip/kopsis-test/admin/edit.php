<?php
require_once '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') header("Location: ../index.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = (int)$_POST['id'];
    $nis     = strtoupper(trim($_POST['nis']));
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $kelas   = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];

    $stmt = $conn->prepare("UPDATE users SET nis=?, name=?, email=?, kelas=?, jurusan=? WHERE id=? AND role='student'");
    $stmt->bind_param("sssssi", $nis, $name, $email, $kelas, $jurusan, $id);
    $stmt->execute();
    header("Location: dashboard.php?updated=1");
    exit;
}
?>