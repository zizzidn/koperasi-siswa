<?php
require_once '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') header("Location: ../index.php");

// Debug: tampilkan semua POST & FILES
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<pre>POST: "; print_r($_POST); echo "</pre>";
    echo "<pre>FILES: "; print_r($_FILES); echo "</pre>";

    $id      = (int)($_POST['id'] ?? 0);
    $nis     = strtoupper(trim($_POST['nis'] ?? ''));
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $kelas   = $_POST['kelas'] ?? '';
    $jurusan = $_POST['jurusan'] ?? '';
    $photo   = $user['photo'] ?? 'assets/img/default.jpg'; // Default

    // Validasi NIS & Email unik (kecuali dirinya sendiri)
    $stmt = $conn->prepare("SELECT id FROM users WHERE (nis=? OR email=?) AND id!=? AND role='student'");
    $stmt->bind_param("ssi", $nis, $email, $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows) {
        echo "<div class='alert alert-danger'>NIS atau Email sudah digunakan!</div>";
        exit;
    }

    // Upload foto (opsional)
    if (!empty($_FILES['photo']['name'])) {
        $file = $_FILES['photo'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];
        if (in_array($ext, $allowed)) {
            $path = "../assets/uploads/" . uniqid() . ".$ext";
            if (move_uploaded_file($file['tmp_name'], $path)) {
                $photo = $path;
                echo "<div class='alert alert-info'>Upload BERHASIL: " . htmlspecialchars(basename($path)) . "</div>";
            } else {
                echo "<div class='alert alert-danger'>Upload GAGAL: pastikan folder writable</div>";
                exit;
            }
        } else {
            echo "<div class='alert alert-warning'>Ekstensi tidak diizinkan</div>";
            exit;
        }
    }

    // Update DB
    $stmt = $conn->prepare("UPDATE users SET nis=?, name=?, email=?, kelas=?, jurusan=?, photo=? WHERE id=? AND role='student'");
    $stmt->bind_param("ssssssi", $nis, $name, $email, $kelas, $jurusan, $photo, $id);
    $stmt->execute();
    echo "<div class='alert alert-success'>Update BERHASIL</div>";
    echo "<a href='dashboard.php' class='btn btn-primary'>Kembali</a>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Debug Edit Siswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
  <h4>Debug Edit Siswa</h4>
  <a href="dashboard.php" class="btn btn-secondary mb-3">Kembali</a>
  <!-- Debug output otomatis di atas -->
</body>
</html>