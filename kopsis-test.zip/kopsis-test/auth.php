<?php
require_once 'config.php';

/* ================= REGISTER SISWA (OTOMATIS STUDENT) ================= */
if (isset($_POST['register_student'])) {
    $nis    = strtoupper(trim($_POST['nis']));
    $name   = trim($_POST['name']);
    $email  = trim($_POST['email']);
    $pass   = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $jurusan= $_POST['jurusan'];
    $kelas  = $_POST['kelas'];
    $role   = 'student'; // OTOMATIS

    // Cek NIS & Email unik
    $stmt = $conn->prepare("SELECT id FROM users WHERE nis=? OR email=?");
    $stmt->bind_param("ss", $nis, $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows) {
        echo "<script>alert('NIS atau Email sudah terdaftar!');history.back();</script>";
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO users (nis,name,email,password,role,jurusan,kelas) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $nis, $name, $email, $pass, $role, $jurusan, $kelas);
    $stmt->execute();
    header("Location: index.php?reg=1");
    exit;
}

/* ================= REGISTER ADMIN (LEWAT HALAMAN ADMIN) ================= */
if (isset($_POST['register_admin'])) {
    $name   = trim($_POST['name']);
    $email  = trim($_POST['email']);
    $pass   = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role   = 'admin'; // OTOMATIS ADMIN
    $jurusan= '-';
    $kelas  = '-';
    $nis    = '-';

    // Cek email unik
    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows) {
        echo "<script>alert('Email sudah terdaftar!');history.back();</script>";
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO users (nis,name,email,password,role,jurusan,kelas) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $nis, $name, $email, $pass, $role, $jurusan, $kelas);
    $stmt->execute();
    header("Location: admin/index.php?reg=1");
    exit;
}

/* ================= LOGIN SISWA ================= */
if (isset($_POST['login_student'])) {
    $email = trim($_POST['email']);
    $stmt  = $conn->prepare("SELECT * FROM users WHERE email=? AND role='student'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($_POST['password'], $user['password'])) {
            $_SESSION['user'] = $user;
            $redirect = $_GET['redirect'] ?? 'student-dashboard.php';
            header("Location: $redirect");
            exit;
        }
    }
    echo "<script>alert('Email/password salah!');history.back();</script>";
    exit;
}

/* ================= LOGIN ADMIN ================= */
if (isset($_POST['login_admin'])) {
    $email = trim($_POST['email']);
    $stmt  = $conn->prepare("SELECT * FROM users WHERE email=? AND role='admin'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($_POST['password'], $user['password'])) {
            $_SESSION['user'] = $user;
            header("Location: admin/dashboard.php");
            exit;
        }
    }
    echo "<script>alert('Email/password salah!');history.back();</script>";
    exit;
}
?>