<?php
require_once 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') header("Location: index.php");

// Handle tambah/hapus/clear
if (isset($_GET['add'])) {
    $id = (int)$_GET['add'];
    $qty = (int)($_GET['qty'] ?? 1);
    $res = $conn->query("SELECT * FROM products WHERE id=$id");
    if ($res->num_rows) {
        $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
    }
    header("Location: cart.php");
    exit;
}
if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][(int)$_GET['remove']]);
    header("Location: cart.php");
    exit;
}
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit;
}

$cart = $_SESSION['cart'];
$items = [];
$total = 0;
foreach ($cart as $id => $qty) {
    $p = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
    $sub = $p['price'] * $qty;
    $total += $sub;
    $items[] = "{$p['name']} ({$qty}x) = Rp " . number_format($sub);
}
$waAdmin = "6289629967066"; // GANTI NOMOR ADMIN

$pesanWA = "Saya ingin checkout keranjang:\n" . implode("\n", $items) . "\nTotal: Rp " . number_format($total) . "\n" . $_SESSION['user']['name'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Keranjang - Koperasi Siswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-4" style="max-width:700px;">
  <h4>Keranjang Belanja</h4>
  <?php if(empty($cart)): ?>
    <div class="alert alert-info">Keranjang kosong.</div>
    <a href="student-dashboard.php" class="btn btn-primary">← Kembali Belanja</a>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table align-middle">
        <thead class="table-light">
          <tr><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach($cart as $id=>$qty):
                $p = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
                $sub = $p['price'] * $qty;
          ?>
            <tr>
              <td>
                <img src="<?= $p['image'] ?>" width="50" height="50" class="rounded me-2"><?= $p['name'] ?>
              </td>
              <td>Rp <?= number_format($p['price']) ?></td>
              <td><?= $qty ?></td>
              <td>Rp <?= number_format($sub) ?></td>
              <td><a href="?remove=<?= $id ?>" class="btn btn-sm btn-danger">Hapus</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="3">Total Keseluruhan</th>
            <th>Rp <?= number_format($total) ?></th>
            <th></th>
          </tr>
        </tfoot>
      </table>
    </div>

    <div class="d-flex gap-2">
      <a href="?clear=1" class="btn btn-warning" onclick="return confirm('Kosongkan keranjang?')">Kosongkan</a>
      <a href="student-dashboard.php" class="btn btn-secondary">← Lanjut Belanja</a>
      <a href="https://wa.me/<?= $waAdmin ?>?text=<?= urlencode($pesanWA) ?>" 
         target="_blank" class="btn btn-success">Checkout via WhatsApp</a>
    </div>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>