<?php
session_start();
// Inisialisasi keranjang jika belum ada
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$conn = new mysqli('localhost', 'root', '', 'kopsis-test');
if ($conn->connect_error) die("Koneksi gagal: " . $conn->connect_error);
?>