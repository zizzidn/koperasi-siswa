<?php require_once 'config.php';
$redirect = $_GET['redirect'] ?? '';
if(isset($_SESSION['user'])){
    header("Location: ".($_SESSION['user']['role']==='admin' ? 'admin/dashboard.php' : 'student-dashboard.php'));
    exit;
}
if(isset($_POST['login_student'])){
    $email = trim($_POST['email']);
    $stmt  = $conn->prepare("SELECT * FROM users WHERE email=? AND role='student'");
    $stmt->bind_param("s",$email); $stmt->execute();
    $res = $stmt->get_result();
    if($res->num_rows===1){
        $user = $res->fetch_assoc();
        if(password_verify($_POST['password'], $user['password'])){
            $_SESSION['user']=$user;
            header("Location: ".($redirect ? $redirect : 'student-dashboard.php'));
            exit;
        }
    }
    echo "<script>alert('Email/password salah!');</script>";
}
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>Login Siswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head>
<body class="bg-light">
<div class="container d-flex align-items-center justify-content-center min-vh-100">
  <div class="card shadow-sm" style="max-width:400px;width:100%;">
    <div class="card-body">
      <h4 class="card-title text-center mb-4">Login Siswa</h4>
      <form method="POST" novalidate>
        <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
        <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required minlength="6"></div>
        <button class="btn btn-primary w-100" name="login_student" type="submit">Login</button>
        <div class="text-center mt-3">
          <small>Belum punya akun? <a href="register.php">Daftar</a></small><br>
          <small>Login sebagai admin? <a href="admin/index.php">Klik di sini</a></small>
        </div>
      </form>
    </div>
  </div>
</div></body></html>