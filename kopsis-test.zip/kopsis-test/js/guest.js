function requireLogin(){
    const modal = new bootstrap.Modal(document.getElementById('loginRequiredModal'));
    modal.show();
}
function goLogin(){
    location.href = 'index.php?redirect=' + encodeURIComponent(location.href);
}