<?php require_once 'config.php';
$isLoggedIn = isset($_SESSION['user']);
$role       = $isLoggedIn ? $_SESSION['user']['role'] : '';
$photo      = $isLoggedIn ? $_SESSION['user']['photo'] : 'assets/img/default.png';
$dashLink   = $isLoggedIn ? ($role==='admin' ? 'admin/dashboard.php' : 'student-dashboard.php') : 'index.php';

// Hitung keranjang
$cart   = $_SESSION['cart'] ?? [];
$jmlItem= array_sum($cart);
$total  = 0;
foreach ($cart as $id=>$qty){
    $h = $conn->query("SELECT price FROM products WHERE id=$id")->fetch_assoc();
    $total += $h['price'] * $qty;
}
$waAdmin= "6289629967066"; // <-- GANTI NOMOR ADMIN
?>
<nav class="navbar navbar-expand-lg navbar-dark navbar-darkblue">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="<?= $dashLink ?>">
      <img src="assets/img/logo.png" alt="Logo" class="me-2">KOPERASI SISWA
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <?php if ($isLoggedIn): ?>
        <!-- TOMBOL KERANJANG (DROPDOWN) -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="cartDropdown" role="button" data-bs-toggle="dropdown">
            🛒 <span class="badge bg-danger ms-1"><?= $jmlItem ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end p-3" style="min-width:320px;">
            <li><h6 class="dropdown-header">Keranjang (<?= $jmlItem ?>)</h6></li>
            <?php if(empty($cart)): ?>
              <li><span class="dropdown-item-text text-muted">Keranjang kosong</span></li>
            <?php else: ?>
              <?php foreach($cart as $id=>$qty):
                    $p = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
                    $sub = $p['price'] * $qty; ?>
                <li class="d-flex justify-content-between align-items-center mb-2">
                  <div>
                    <div class="fw-bold"><?= $p['name'] ?></div>
                    <small class="text-muted"><?= number_format($p['price']) ?> x <?= $qty ?></small>
                  </div>
                  <span class="badge bg-success">Rp <?= number_format($sub) ?></span>
                </li>
              <?php endforeach; ?>
              <li><hr class="dropdown-divider"></li>
              <li class="d-flex justify-content-between align-items-center">
                <span class="fw-bold">Total</span>
                <span class="badge bg-primary">Rp <?= number_format($total) ?></span>
              </li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <a class="btn btn-success btn-sm w-100" 
                   href="https://wa.me/<?= $waAdmin ?>?text=<?= urlencode("Saya ingin checkout keranjang:\n".implode("\n",array_map(fn($id,$qty)=>$conn->query("SELECT name FROM products WHERE id=$id")->fetch_assoc()['name']." (".$qty."x)",array_keys($cart),$cart))."\nTotal Rp ".number_format($total)."\n".$_SESSION['user']['name']) ?>" 
                   target="_blank">Checkout via WhatsApp</a>
              </li>
              <li><a class="btn btn-outline-secondary btn-sm w-100 mt-2" href="cart.php">Lihat Detail</a></li>
            <?php endif; ?>
          </ul>
        </li>

        <!-- TOMBOL FOTO PROFIL (DROPDOWN) -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown">
            <img src="<?= $photo ?>" alt="Foto Profil" class="nav-profile-img">
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
          </ul>
        </li>
        <?php else: ?>
        <!-- Belum Login -->
        <li class="nav-item"><a class="nav-link" href="index.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- CSS & JS WAJIB -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap/5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="assets/css/style.css">