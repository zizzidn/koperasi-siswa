<?php
require_once 'config.php';
if (!isset($_SESSION['user'])) header("Location: index.php");

$user = $_SESSION['user'];
$msg = '';

// Data dropdown
$jurusan_list = ['IPA', 'IPS', 'Bahasa', 'Agama'];
$kelas_list   = ['X-1','X-2','X-3','XI-1','XI-2','XI-3','XII-1','XII-2','XII-3'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']);
    $desc    = trim($_POST['description']);
    $jurusan = $_POST['jurusan'];
    $kelas   = $_POST['kelas'];
    $photo   = $user['photo']; // default: foto lama

    // NIS hanya admin yang bisa edit
    if ($user['role'] === 'admin') {
        $nis = strtoupper(trim($_POST['nis']));
    } else {
        $nis = $user['nis'];
    }

    // === UPLOAD FOTO ===
    if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['photo'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];

        if (in_array($ext, $allowed)) {
            $newname = uniqid() . "." . $ext;
            $path = "assets/uploads/" . $newname;

            if (move_uploaded_file($file['tmp_name'], $path)) {
                $photo = $path;
            }
        }
    }

    // Update DB
    $stmt = $conn->prepare("UPDATE users 
        SET nis=?, name=?, description=?, photo=?, jurusan=?, kelas=? 
        WHERE id=?");
    $stmt->bind_param("ssssssi", $nis, $name, $desc, $photo, $jurusan, $kelas, $user['id']);
    $stmt->execute();

    // Refresh session
    $_SESSION['user'] = $conn->query("SELECT * FROM users WHERE id={$user['id']}")->fetch_assoc();
    $user = $_SESSION['user'];

    $msg = '<div class="alert alert-success alert-dismissible fade show" role="alert">
              <i class="bi bi-check-circle me-2"></i> Profile berhasil diperbarui.
              <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>';
}

// Fallback foto default
$foto = !empty($user['photo']) ? $user['photo'] : 'assets/img/default.png';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<?php include 'navbar.php'; ?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-6">

      <?= $msg ?>

      <div class="card shadow border-0">
        <div class="card-header bg-gradient-primary text-white text-center">
          <h4 class="mb-0"><i class="bi bi-person-circle me-2"></i>Profile Siswa</h4>
        </div>

        <div class="card-body p-4">

          <!-- FORM START -->
          <form method="POST" enctype="multipart/form-data">

            <!-- FOTO PROFIL -->
            <div class="text-center mb-4">
              <img id="preview" 
                   src="<?= $foto ?>" 
                   alt="Foto Profil"
                   class="rounded-circle border border-3 shadow-sm"
                   width="150" height="150">

              <div class="mt-3">
                <input type="file" 
                       class="form-control w-auto d-inline"
                       name="photo"
                       accept="image/*"
                       onchange="previewFile(this)">
              </div>
            </div>

            <!-- BUTTON DASHBOARD -->
            <div class="mb-3">
              <a href="<?= ($user['role']==='admin' ? 'admin/dashboard.php' : 'student-dashboard.php') ?>" 
                 class="btn btn-outline-secondary btn-sm w-100">
                 <i class="bi bi-arrow-left me-1"></i>Kembali ke Dashboard
              </a>
            </div>

            <!-- NIS -->
            <div class="mb-3">
              <label class="form-label fw-bold"><i class="bi bi-hash me-1"></i>NIS</label>
              <input type="text" name="nis" class="form-control"
                     value="<?= htmlspecialchars($user['nis']) ?>"
                     <?= ($user['role']!=='admin')?'readonly':'' ?> required>
              
              <?php if($user['role']!=='admin'): ?>
                <small class="text-muted"><i class="bi bi-lock me-1"></i>Hanya admin yang bisa mengubah NIS</small>
              <?php endif; ?>
            </div>

            <!-- NAME -->
            <div class="mb-3">
              <label class="form-label fw-bold"><i class="bi bi-person me-1"></i>Nama Lengkap</label>
              <input type="text" name="name" class="form-control"
                     value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>

            <!-- EMAIL -->
            <div class="mb-3">
              <label class="form-label fw-bold"><i class="bi bi-envelope me-1"></i>Email</label>
              <input type="email" class="form-control" 
                     value="<?= htmlspecialchars($user['email']) ?>" readonly>
            </div>

            <!-- JURUSAN -->
            <div class="mb-3">
              <label class="form-label fw-bold"><i class="bi bi-book me-1"></i>Jurusan</label>
              <select name="jurusan" class="form-select" required>
                <?php foreach ($jurusan_list as $j): ?>
                  <option value="<?= $j ?>" <?= $j==$user['jurusan']?'selected':'' ?>><?= $j ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- KELAS -->
            <div class="mb-3">
              <label class="form-label fw-bold"><i class="bi bi-door-open me-1"></i>Kelas</label>
              <select name="kelas" class="form-select" required>
                <?php foreach ($kelas_list as $k): ?>
                  <option value="<?= $k ?>" <?= $k==$user['kelas']?'selected':'' ?>><?= $k ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- DESKRIPSI -->
            <div class="mb-4">
              <label class="form-label fw-bold"><i class="bi bi-card-text me-1"></i>Deskripsi</label>
              <textarea name="description" class="form-control" rows="3"
                        placeholder="Tulis sesuatu tentang Anda..."><?= htmlspecialchars($user['description']) ?></textarea>
            </div>

            <!-- SIMPAN -->
            <button class="btn btn-primary w-100" type="submit">
              <i class="bi bi-save me-2"></i>Simpan Perubahan
            </button>

          </form>
          <!-- FORM END -->

        </div>
      </div>
    </div>
  </div>
</div>

<script>
function previewFile(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => document.getElementById('preview').src = e.target.result;
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
