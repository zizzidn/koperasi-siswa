<?php
require_once 'config.php';
if(isset($_SESSION['user'])) header("Location: student-dashboard.php");

$jurusan_list = ['IPA', 'IPS', 'Bahasa', 'Agama', 'IPS'];
$kelas_list   = ['X-1', 'X-2', 'X-3', 'XI-1', 'XI-2', 'XI-3', 'XII-1', 'XII-2', 'XII-3'];

if(isset($_POST['register'])){
    $nis   = strtoupper(trim($_POST['nis']));
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $jurusan= $_POST['jurusan'];
    $kelas = $_POST['kelas'];
    $role  = 'student'; // OTOMATIS SISWA

    // Cek NIS & Email unik
    $stmt = $conn->prepare("SELECT id FROM users WHERE nis=? OR email=?");
    $stmt->bind_param("ss", $nis, $email);
    $stmt->execute();
    if($stmt->get_result()->num_rows){
        echo "<script>alert('NIS atau Email sudah terdaftar!');history.back();</script>";
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO users (nis,name,email,password,role,jurusan,kelas) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $nis, $name, $email, $pass, $role, $jurusan, $kelas);
    $stmt->execute();
    header("Location: index.php?reg=1");
}
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>Daftar Siswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container d-flex align-items-center justify-content-center min-vh-100">
  <div class="card shadow-sm" style="max-width:420px;width:100%;">
    <div class="card-body">
      <h4 class="card-title text-center mb-4">Daftar Siswa</h4>
      <form method="POST" novalidate>
        <div class="mb-3"><label>NIS</label><input type="text" name="nis" class="form-control" required></div>
        <div class="mb-3"><label>Nama Lengkap</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
        <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required minlength="6"></div>
        <div class="mb-3"><label>Jurusan</label>
          <select name="jurusan" class="form-select" required>
            <option value="" disabled selected>Pilih Jurusan</option>
            <?php foreach($jurusan_list as $j): ?>
              <option value="<?= $j ?>"><?= $j ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3"><label>Kelas</label>
          <select name="kelas" class="form-select" required>
            <option value="" disabled selected>Pilih Kelas</option>
            <?php foreach($kelas_list as $k): ?>
              <option value="<?= $k ?>"><?= $k ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button class="btn btn-success w-100" name="register" type="submit">Daftar</button>
        <div class="text-center mt-3">
          <small>Sudah punya akun? <a href="index.php">Login di sini</a></small>
        </div>
      </form>
    </div>
  </div>
</div></body></html>