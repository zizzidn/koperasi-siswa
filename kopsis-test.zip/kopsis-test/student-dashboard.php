<?php
require_once 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') header("Location: index.php");

$user = $_SESSION['user'];         // <-- BARIS BARU
$products = $conn->query("SELECT * FROM products WHERE stock > 0");
$waAdmin  = "6289629967066"; // GANTI NOMOR ADMIN
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Siswa - Koperasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">

<!-- ========== NAVBAR + MODAL ========== -->
<?php include 'navbar.php'; include 'modal_login_required.php'; ?>

<!-- ========== HERO SECTION ========== -->
<section class="hero bg-gradient-primary text-white py-5">
  <div class="container text-center">
    <h1 class="display-5 fw-bold">Selamat datang, <?= htmlspecialchars($user['name']) ?>!</h1>
    <p class="lead mb-0">Koperasi Siswa – Belanja kebutuhanmu dengan mudah.</p>
  </div>
</section>

<!-- ========== PRODUK SECTION ========== -->
<section class="py-5">
  <div class="container">
    <h2 class="text-center mb-4"><i class="bi bi-shop me-2"></i>Produk Tersedia</h2>

    <div class="row g-4">
      <?php while ($p = $products->fetch_assoc()): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card h-100 shadow-sm product-card">
            <img src="<?= $p['image'] ?>" class="card-img-top" alt="<?= $p['name'] ?>" style="height:200px;object-fit:cover;">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title fw-bold"><?= $p['name'] ?></h5>
              <p class="card-text flex-grow-1"><?= nl2br(htmlspecialchars($p['description'])) ?></p>

              <!-- Info Harga & Stok -->
              <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="badge bg-success fs-6">Rp <?= number_format($p['price']) ?></span>
                <small class="text-muted">Stok: <?= $p['stock'] ?></small>
              </div>

              <!-- Tombol Aksi -->
              <div class="d-grid gap-2 d-md-flex">
                <a href="cart.php?add=<?= $p['id'] ?>&qty=1" class="btn btn-primary btn-sm flex-fill">
                  <i class="bi bi-cart-plus me-1"></i>Keranjang
                </a>
                <a href="https://wa.me/<?= $waAdmin ?>?text=<?= urlencode("Saya ingin membeli *{$p['name']}* (Rp " . number_format($p['price']) . ") - {$_SESSION['user']['name']} (Kelas: {$_SESSION['user']['kelas']}, Jurusan: {$_SESSION['user']['jurusan']})") ?>" 
                   target="_blank" class="btn btn-success btn-sm flex-fill">
                  <i class="bi bi-whatsapp me-1"></i>Beli via WA
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<!-- ========== FOOTER KECIL ========== -->
<footer class="bg-dark text-white py-3 mt-5">
  <div class="container text-center">
    <small>&copy; <?= date('Y') ?> Koperasi Siswa – All rights reserved.</small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/guest.js"></script>
</body>
</html>